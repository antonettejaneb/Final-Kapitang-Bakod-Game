var Gameover = {
	preload : function() {
		   game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
            game.stage.backgroundColor = 'blue'; 
		 game.load.image('menu', 'assets/gameover.png');
	},
	create : function() {

        this.add.sprite(0, 0, 'menu');
             this.add.button(0, 0, 'menu', this.startGame, this);

	},
	 startGame: function () {

        this.state.start('Game');


}
}
game.state.add("Gameover",Gameover,false);

var Gameover2 = {
	preload : function() {
		   game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
            game.stage.backgroundColor = 'blue'; 
		 game.load.image('menu', 'assets/gameover.png');
	},
	create : function() {

        this.add.sprite(0, 0, 'menu');
             this.add.button(0, 0, 'menu', this.startGame, this);

	},
	 startGame: function () {

        this.state.start('Game2');


}
}
game.state.add("Gameover2",Gameover2,false);

var Gameover3 = {
	preload : function() {
		   game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
            game.stage.backgroundColor = 'blue'; 
		 game.load.image('menu', 'assets/gameover.png');
	},
	create : function() {

        this.add.sprite(0, 0, 'menu');
             this.add.button(0, 0, 'menu', this.startGame, this);

	},
	 startGame: function () {

        this.state.start('Game3');


}
}
game.state.add("Gameover3",Gameover3,false);

var Gameover4 = {
	preload : function() {
		   game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
            game.stage.backgroundColor = 'blue'; 
		 game.load.image('menu', 'assets/gameover.png');
	},
	create : function() {

        this.add.sprite(0, 0, 'menu');
             this.add.button(0, 0, 'menu', this.startGame, this);

	},
	 startGame: function () {

        this.state.start('Game4');


}
}
game.state.add("Gameover4",Gameover4,false);

var Gameover5 = {
	preload : function() {
		   game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
            game.stage.backgroundColor = 'blue'; 
		 game.load.image('menu', 'assets/gameover.png');
	},
	create : function() {

        this.add.sprite(0, 0, 'menu');
             this.add.button(0, 0, 'menu', this.startGame, this);

	},
	 startGame: function () {

        this.state.start('Game5');


}
}
game.state.add("Gameover5",Gameover5,false);