var bounds = 3000;
var text;
var joey, joeys, dedee, dedees , marky, markys;
var stars , star;
var fence, wood;
var weapon;
var dedees22, markys33;
var bombs;
var wins;
var bullets3;
var Game3 = {
 preload: function() {
 
            game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
            game.stage.backgroundColor = 'blue'; 
   
            game.load.image("bird", 'assets/bird.png');
                game.load.image("star", 'assets/star.png',process.start);
              game.load.image("sky", 'assets/bg.jpg');
            game.load.spritesheet("oggy", 'assets/oggy.png',83,85);
             game.load.image("bg1", 'assets/road.jpg');
                    game.load.image("ipis1", 'assets/ipis1.png');
                     game.load.image("ipis2", 'assets/ipis2.png');
                      game.load.image("ipis3", 'assets/ipis3.png');
                       game.load.image("fence", 'assets/fence.png');
                            game.load.image("left", 'assets/leftbtn.png');
                       game.load.image("right", 'assets/rightbtn.png');
                          game.load.image("pause", 'assets/pause.png');
                               game.load.image("level3", 'assets/level3.png');
                                    game.load.image("bullet", 'assets/bullet.png');
                                      game.load.image("fire", 'assets/fire.png');
                                        game.load.image("next", 'assets/next.png');
                                         game.load.image("bomb", 'assets/bomb.png');
             
                                             game.load.audio("pew", 'music/pew.mp3');
 


},
 create: function() {

            game.physics.startSystem(Phaser.Physics.ARCADE);


            game.add.sprite(0, 0, 'sky');
            platforms = game.add.group();
            platforms.enableBody = true;
             soundeffects = game.add.audio("pew"); 
          
            level = game.add.group();
            level.enableBody=true;
            var hazel = level.create(600,10,"level3")
            hazel.body.immovable=true;
            fence = game.add.group();
            fence.enableBody= true;
    
   
            laser3 = game.add.group();
            laser3.enableBody=true;



            btn = game.add.button(320,530,"fire",process.bullet3);
            btn.fixedToCamera=true;


              game.input.onDown.add(process.unpause, self);
            var wood = fence.create(0,500,"fence");
            wood.body.immovable=true;
            btn = game.add.button(10,60,"pause",process.pause);
            btn.fixedToCamera=true;
           
             buttonleft = game.add.button(66, 500, 'left');
                buttonleft.anchor.setTo(0.5, 0.5);
                        buttonleft.anchor.setTo(0.5, 0.5);
                             buttonleft.scale.x = -3;
                buttonleft.scale.y = 3;
                buttonleft.fixedToCamera = true;
                buttonleft.events.onInputOver.add(function(){left=true;});
                buttonleft.events.onInputOut.add(function(){left=false;});
                buttonleft.events.onInputDown.add(function(){left=true;});
                buttonleft.events.onInputUp.add(function(){left=false;});
              
             buttonright = game.add.button(640, 500, 'right');
                buttonright.anchor.setTo(0.5, 0.5);
                         buttonright.anchor.setTo(0.5, 0.5);
                             buttonright.scale.x = 3;
                buttonright.scale.y = 3;
                buttonright.fixedToCamera = true;
                buttonright.events.onInputOver.add(function(){right=true;});
                buttonright.events.onInputOut.add(function(){right=false;});
                buttonright.events.onInputDown.add(function(){right=true;});
                buttonright.events.onInputUp.add(function(){right=false;});


         
     
                 process.level4(20000);

                level4 = game.add.group();
                level4.enableBody=true;

                process.createDedees22(2000);

                dedee22 = game.add.group();
                dedee22.enableBody=true;

                process.createMarkys33(2000);

                marky33 = game.add.group();
                marky33.enableBody=true;


                process.createBombs(10000);
            bomb = game.add.group();
            bomb.enableBody=true;
        
      
            player = game.add.sprite(200, game.world.height - 400, 'oggy');
            game.physics.arcade.enable(player);
              
           

            player.body.bounce.y = 0.2;
            player.body.gravity.y = 300;
            player.body.collideWorldBounds = true;
            player.animations.add('left', [6, 7, 8],10, true); 
            player.animations.add('right', [3, 4, 5],10, true); 
            scoreText = game.add.text(16, 16, 'Kill: 0', { fontSize: '32px', fill: 'white' });
            messageText = game.add.text(180, 180, '', { fontSize: '120px', fill: 'red' });
            pauseText = game.add.text(180, 180, '', { fontSize: '120px', fill: 'white' });
            game.camera.follow(player, Phaser.Camera.FOLLOW_TOPDOWN);
            scoreText.fixedToCamera = true;
            messageText.fixedToCamera = true;
            game.camera.follow(player, Phaser.Camera.FOLLOW_LOCKON);
            cursors = game.input.keyboard.createCursorKeys();     




  

        },

update: function() {


    game.physics.arcade.collide(fence,player);


    game.physics.arcade.overlap(fence,  dedee22, process.killDedee22, null, this);
      game.physics.arcade.overlap(fence, marky33, process.killMarky33, null, this);




    game.physics.arcade.overlap(laser3,  dedee22, process.kill22, null, this);
      game.physics.arcade.overlap(laser3, marky33, process.kill33, null, this);
        game.physics.arcade.overlap(laser3, bomb, process.killMe, null, this);
           game.physics.arcade.overlap(laser3, level4, process.next4, null, this);
              



 


      
    

            if (left) {
               
                player.body.velocity.x=-320;
                player.animations.play('left');
            }
            else if (right) {
          
                player.body.velocity.x=320;
                player.animations.play('right');
            } 
            else {
                   player.body.velocity.x=0;

              player.frame = 1;
            }

            if (game.input.currentPointers == 0 && !game.input.activePointer.isMouse){ fire=false; right=false; left=false; duck=false; jump=false;} //this 
        }

}
game.state.add("Game3" ,Game3, false);