
var w = 700;
var h = 620;
var platform,bg,crystal,ghost,platforms,scoreText,gameOverText,ghosts,crystals,bestText;
var platform,bg,crystal,ghost,platforms,scoreText,gameOverText,ghosts,crystals;
var player;
var platforms;
var cursors, ledge;
   var left=false;
        var right=false;

var bullets;

var cursors;


var basicGame;
var stars , star;
var anons;
var score = 0;
var scoreText;
var demonyos;
var bestScoreText;
var bgAudio1 , bgAudio2 , bgAudio3;
var soundeffects;
var btn;
var hazel;
var start;
var bg1, bg2, bg3, bg4;
var audio, audio1, audio2;
game = new Phaser.Game(w, h, Phaser.CANVAS, '');

game.state.add('Menu', Menu);


game.state.start('Menu');

game.state.add('Game');
game.state.add('Game2');
game.state.add('Game3');
game.state.add('Game4');
game.state.add('Game5');
game.state.add('Gameover');
game.state.add('Gameover2');
game.state.add('Gameover3');
game.state.add('Gameover4');
game.state.add('Gameover5');
game.state.add('Win');

