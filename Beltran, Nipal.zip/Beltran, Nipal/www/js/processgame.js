var process = function() {
	   "use strict";
        return {


 

createJoeys : function (time) {
    setInterval(function() {
        joeys= joey.create(Math.random()*900, -100, "ipis1");
        joeys.body.gravity.y = 20;
 

        joeys.body.collideWorldBounds = true;
    },time);
}, 

createDedees : function (time) {
    setInterval(function() {
        dedees= dedee.create(Math.random()*900, -100, "ipis2");
        dedees.body.gravity.y = 20;
 

        dedees.body.collideWorldBounds = true;
    },time);
}, 

createMarkys : function (time) {
    setInterval(function() {
        markys= marky.create(Math.random()*900, -100, "ipis3");
        markys.body.gravity.y = 20;
 

        markys.body.collideWorldBounds = true;
    },time);
}, 

createDedees22 : function (time) {
    setInterval(function() {
        dedees22= dedee22.create(Math.random()*900, -100, "ipis2");
        dedees22.body.gravity.y = 20;
 

        dedees22.body.collideWorldBounds = true;
    },time);
}, 

createMarkys33 : function (time) {
    setInterval(function() {
        markys33= marky33.create(Math.random()*900, -100, "ipis3");
        markys33.body.gravity.y = 20;
 

        markys33.body.collideWorldBounds = true;
    },time);
}, 


createDedees222 : function (time) {
    setInterval(function() {
        dedees222= dedee222.create(Math.random()*900, -100, "ipis2");
        dedees222.body.gravity.y = 20;
 

        dedees222.body.collideWorldBounds = true;
    },time);
}, 

createMarkys333 : function (time) {
    setInterval(function() {
        markys333= marky333.create(Math.random()*900, -100, "ipis3");
        markys333.body.gravity.y = 20;
 

        markys333.body.collideWorldBounds = true;
    },time);
}, 

createDedees2222 : function (time) {
    setInterval(function() {
        dedees2222= dedee2222.create(Math.random()*900, -100, "ipis2");
        dedees2222.body.gravity.y = 20;
 

        dedees2222.body.collideWorldBounds = true;
    },time);
}, 

createMarkys3333 : function (time) {
    setInterval(function() {
        markys3333= marky333.create(Math.random()*900, -100, "ipis3");
        markys3333.body.gravity.y = 20;
 

        markys3333.body.collideWorldBounds = true;
    },time);
}, 

createBombs : function (time) {
    setInterval(function() {
        bombs= bomb.create(Math.random()*900, -100, "bomb");
        bombs.body.gravity.y = 150;
 

        bombs.body.collideWorldBounds = false;
    },time);
}, 

createBombs1 : function (time) {
    setInterval(function() {
        bombs1= bomb1.create(Math.random()*900, -100, "bomb");
        bombs1.body.gravity.y = 160;
 

        bombs1.body.collideWorldBounds = false;
    },time);
}, 

createBombs11 : function (time) {
    setInterval(function() {
        bombs11= bomb11.create(Math.random()*900, -100, "bomb");
        bombs11.body.gravity.y = 170;
 

        bombs11.body.collideWorldBounds = false;
    },time);
}, 


 killJoey: function(player, joey) {
    
  
    joey.kill();
    soundeffects.play();
    score += 1; 
    scoreText.text = 'Kill:' + score;

  

},
 killDedee: function(player, dedee) {
    
    
    dedee.kill();
    soundeffects.play();
    score += 1; 
    scoreText.text = 'Kill:' + score;

},
 killMarky: function(player, marky) {
    
  
    marky.kill();
    soundeffects.play();
    score += 1; 
    scoreText.text = 'Kill:' + score;

},

 killDedee22: function(player, dedee22) {
    
   
    dedee22.kill();
    soundeffects.play();
    score += 1; 
    scoreText.text = 'Kill:' + score;

},
 killMarkys33: function(player, marky33) {
    
    marky33.kill();
    soundeffects.play();
    score += 1; 
    scoreText.text = 'Kill:' + score;

},


 killDedee22: function(player, dedee222) {
    
   
    dedee222.kill();
    soundeffects.play();
    score += 1; 
    scoreText.text = 'Kill:' + score;

},
 killMarkys33: function(player, marky333) {
    
    marky333.kill();
    soundeffects.play();
    score += 1; 
    scoreText.text = 'Kill:' + score;

},
killJoey1: function(fence, joey) {
    
   
game.state.start("Gameover");
 

  

},
 killDedee2: function(fence, dedee) {
    
   
game.state.start("Gameover2");


},
 killMarky3: function(fence, marky) {
    
   
game.state.start("Gameover2");
 
},

 killDedee22: function(fence, dedee22) {
    
   
game.state.start("Gameover3");


},
 killMarky33: function(fence, marky33) {
    
   
game.state.start("Gameover3");
 
},

 killDedee222: function(fence, dedee222) {
    
   
game.state.start("Gameover4");


},
 killMarky333: function(fence, marky333) {
    
   
game.state.start("Gameover4");
 
},

 killDedee2222: function(fence, dedee2222) {
    
   
game.state.start("Gameover5");


},
 killMarky3333: function(fence, marky333) {
    
   
game.state.start("Gameover5");
 
},

 killMe: function(laser3, bomb) {
    
    
game.state.start("Gameover3");
 
},

 killMe1: function(laser5, bomb1) {
    
    
game.state.start("Gameover4");
 
},
 killMe2: function(laser6, bomb11) {
    
    
game.state.start("Gameover5");
 
},
 
audio : function(time){
    setInterval(function(){
        bgAudio.play();
        },time)
 

},
    pause : function(){
    game.paused = true;
    pauseText.text = 'GAME PAUSED , tap to unpause';
},

  unpause:  function (event){
     
   game.paused = false;
   pauseText.text = "";
},

bullet : function(){
     bullets= laser.create(player.body.x +player.body.width/2+20, player.body.y + player.body.height/2 -4,"bullet");
        bullets.body.gravity.y = -1000;
 

        bullets.body.collideWorldBounds = false;
},

bullet2 : function(){
     bullets2= laser2.create(player.body.x +player.body.width/2+20, player.body.y + player.body.height/2 -4,"bullet");
        bullets2.body.gravity.y = -1000;
 

        bullets2.body.collideWorldBounds = false;
},


bullet3 : function(){
     bullets3= laser3.create(player.body.x +player.body.width/2+20, player.body.y + player.body.height/2 -4,"bullet");
        bullets3.body.gravity.y = -1000;
 

        bullets3.body.collideWorldBounds = false;
},

bullet5 : function(){
     bullets5= laser5.create(player.body.x +player.body.width/2+20, player.body.y + player.body.height/2 -4,"bullet");
        bullets5.body.gravity.y = -1000;
 

        bullets5.body.collideWorldBounds = false;
},


bullet6 : function(){
     bullets6= laser6.create(player.body.x +player.body.width/2+20, player.body.y + player.body.height/2 -4,"bullet");
        bullets6.body.gravity.y = -1000;
 

        bullets6.body.collideWorldBounds = false;
},




 kill1: function(laser, joey) {
    
    
joey.kill();
 soundeffects.play();
    score += 1; 
    scoreText.text = 'Kill:' + score;
 
},
  kill2: function(laser2, dedee) {
    
   
dedee.kill();
 soundeffects.play();
    score += 1; 
    scoreText.text = 'Kill:' + score;
 
},
 kill3: function(laser2, marky) {
    
    
marky.kill();
 soundeffects.play();
    score += 1; 
    scoreText.text = 'Kill:' + score;
 
},  

  kill22: function(laser3, dedee22) {
    
    
dedee22.kill();
 soundeffects.play();
    score +=1;
    scoreText.text = 'Kill:' + score;
 
},
 kill33: function(laser3, marky33) {
    
    
marky33.kill();
 soundeffects.play();
    score += 1; 
    scoreText.text = 'Kill:' + score;
 
},    

  kill222: function(laser5, dedee222) {
    
    
dedee222.kill();
 soundeffects.play();
    score +=1;
    scoreText.text = 'Kill:' + score;
 
},
 kill333: function(laser5, marky333) {
    
    
marky333.kill();
 soundeffects.play();
    score += 1; 
    scoreText.text = 'Kill:' + score;
 
}, 
  kill2222: function(laser5, dedee2222) {
    
    
dedee2222.kill();
 soundeffects.play();
    score +=1;
    scoreText.text = 'Kill:' + score;
 
},
 kill3333: function(laser5, marky3333) {
    
    
marky3333.kill();
 soundeffects.play();
    score += 1; 
    scoreText.text = 'Kill:' + score;
 
}, 
level2 : function (time) {
    setInterval(function() {
        twos= level2.create(Math.random()*900, -100, "next");
        twos.body.gravity.y = 60;
 

        twos.body.collideWorldBounds = false;
    },time);
}, 

level3 : function (time) {
    setInterval(function() {
        tres= level3.create(Math.random()*900, -100, "next");
        tres.body.gravity.y = 60;
 

        tres.body.collideWorldBounds = false;
    },time);
}, 

level4 : function (time) {
    setInterval(function() {
        kwatro= level4.create(Math.random()*900, -100, "next");
        kwatro.body.gravity.y = 60;
 

        kwatro.body.collideWorldBounds = false;
    },time);
}, 

level5 : function (time) {
    setInterval(function() {
        lima= level5.create(Math.random()*900, -100, "next");
        lima.body.gravity.y = 60;
 

        lima.body.collideWorldBounds = false;
    },time);
}, 



congrats : function (time) {
    setInterval(function() {
        wins= win.create(Math.random()*900, -100, "next");
        wins.body.gravity.y = 60;
 

        wins.body.collideWorldBounds = false;
    },time);
}, 
next2 : function(laser, level2) {
    game.state.start("Game2");
},

next3 : function(laser2, level3) {
    game.state.start("Game3");
},

next4 : function(laser3, level4) {
    game.state.start("Game4");
},

next5 : function(laser5, level5) {
    game.state.start("Game5");
},


killWinner : function(laser6, win){
    game.state.start("Win");
},
 
}
}();